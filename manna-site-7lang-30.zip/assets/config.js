// ───── 만나 퍼즐 설정: 이 파일만 고치면 됩니다 ─────
window.MANNA = {
  // 애드센스 승인 후 받은 게시자 ID (예: "ca-pub-1234567890123456")
  // 그대로 두면 광고 코드가 아예 실리지 않습니다.
  adClient: "ca-pub-2164050743743017",
  // 애드센스에서 만든 "디스플레이 광고 단위"의 슬롯 번호 (예: "1234567890")
  adSlot: "0000000000",
  // 1/365 퍼즐이 열리는 날 (이 날부터 하루에 한 판씩 번호가 올라갑니다)
  startDate: "2026-11-16",
  // 문의 이메일 (개인정보처리방침·문의 페이지에 표시)
  contactEmail: "3318phgy@gmail.com",
  // 운영자 이름 또는 팀 이름
  operator: "만나 퍼즐 운영팀"
};

// 광고 불러오기: 게시자 ID를 넣었을 때만 동작
(function(){
  var c = window.MANNA.adClient;
  if (!c || /0{16}$/.test(c)) return;
  // 애드센스 스크립트는 각 페이지 <head>에 직접 넣어 두었습니다(사이트 확인용).
  // 광고 단위 슬롯 번호를 넣기 전에는 광고 칸을 채우지 않음 (사이트 확인·자동 광고는 위 스크립트만으로 동작)
  if (!window.MANNA.adSlot || /^0+$/.test(window.MANNA.adSlot)) return;
  document.addEventListener("DOMContentLoaded", function(){
    document.querySelectorAll("ins.adsbygoogle").forEach(function(ins){
      ins.setAttribute("data-ad-client", c);
      ins.setAttribute("data-ad-slot", window.MANNA.adSlot);
      ins.closest(".adslot") && ins.closest(".adslot").removeAttribute("hidden");
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
    });
  });
})();

// 연락처·운영자 표시
document.addEventListener("DOMContentLoaded", function(){
  document.querySelectorAll("[data-email]").forEach(function(e){ e.textContent = window.MANNA.contactEmail; });
  document.querySelectorAll("[data-operator]").forEach(function(e){ e.textContent = window.MANNA.operator; });
});

// 홈 화면 설치(오프라인 지원)
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function(){ navigator.serviceWorker.register("/sw.js").catch(function(){}); });
}

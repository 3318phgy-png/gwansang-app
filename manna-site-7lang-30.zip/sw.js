// 오프라인에서도 열리도록 기본 파일을 저장해 둡니다. 내용을 바꾸면 VERSION 숫자를 올리세요.
const VERSION = "manna-v12";
const CORE = ["./","index.html","about.html","howto.html","verses.html","privacy.html","contact.html",
  "assets/config.js","assets/site.css","data/puzzles.json","data/verses.json","manifest.webmanifest","icons/icon-192.png",
  "en/","en/index.html","en/data/puzzles.json","en/data/verses.json",
  "es/","es/index.html","es/data/puzzles.json","es/data/verses.json",
  "fr/","fr/index.html","fr/data/puzzles.json","fr/data/verses.json",
  "de/","de/index.html","de/data/puzzles.json","de/data/verses.json",
  "zh/","zh/index.html","zh/data/puzzles.json","zh/data/verses.json",
  "ja/","ja/index.html","ja/data/puzzles.json","ja/data/verses.json"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE))); self.skipWaiting(); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))));
  self.clients.claim();
});
// 같은 사이트 파일만 다룹니다(광고·글꼴 등 외부 요청은 건드리지 않음). 새 내용을 먼저 받고, 안 되면 저장본을 씁니다.
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(res => {
    const copy = res.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); return res;
  }).catch(() => caches.match(e.request).then(r => r || caches.match("index.html"))));
});
